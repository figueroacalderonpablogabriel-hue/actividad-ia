// Interactividad y Validación para TaskFlow
document.addEventListener('DOMContentLoaded', () => {
    // 1. Menú Móvil Desplegable
    const menuToggle = document.getElementById('menu-toggle');
    const navMenu = document.getElementById('nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');

    if (menuToggle && navMenu) {
        menuToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
        });

        // Cerrar menú al hacer click en un enlace
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('active');
            });
        });
    }

    // 2. Validación del Formulario de Registro
    const leadForm = document.getElementById('lead-form');
    const formMessage = document.getElementById('form-message');

    if (leadForm) {
        leadForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            let isValid = true;

            // Elementos del formulario
            const fullname = document.getElementById('fullname');
            const email = document.getElementById('email');
            const role = document.getElementById('role');
            const terms = document.getElementById('terms');

            // Expresión regular para correo electrónico
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            // Validar Nombre
            if (!fullname.value.trim()) {
                setError(fullname, 'error-fullname', true);
                isValid = false;
            } else {
                setError(fullname, 'error-fullname', false);
            }

            // Validar Email
            if (!email.value.trim() || !emailRegex.test(email.value.trim())) {
                setError(email, 'error-email', true);
                isValid = false;
            } else {
                setError(email, 'error-email', false);
            }

            // Validar Ocupación
            if (!role.value) {
                setError(role, 'error-role', true);
                isValid = false;
            } else {
                setError(role, 'error-role', false);
            }

            // Validar Términos
            const errorTerms = document.getElementById('error-terms');
            if (!terms.checked) {
                errorTerms.classList.add('invalid');
                isValid = false;
            } else {
                errorTerms.classList.remove('invalid');
            }

            // Si el formulario es válido
            if (isValid) {
                formMessage.className = 'form-message success';
                formMessage.innerHTML = '<strong>¡Registro exitoso!</strong> Gracias por unirte a la Beta de TaskFlow. Te contactaremos pronto.';
                leadForm.reset();

                // Limpiar mensaje tras 5 segundos
                setTimeout(() => {
                    formMessage.style.display = 'none';
                    formMessage.className = 'form-message';
                }, 5000);
            }
        });
    }

    // Función auxiliar para gestionar errores de validación
    function setError(inputElement, errorId, isError) {
        const parent = inputElement.parentElement;
        const errorSpan = document.getElementById(errorId);

        if (isError) {
            parent.classList.add('invalid');
            if (errorSpan) errorSpan.style.display = 'block';
        } else {
            parent.classList.remove('invalid');
            if (errorSpan) errorSpan.style.display = 'none';
        }
    }
});
