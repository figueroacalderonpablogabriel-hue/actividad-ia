# 02. Registro de Prompts y Experimentos de Prompt Engineering

## Actividad 2: Priming
**Prompt enviado:**
> Actúa como un desarrollador frontend senior especializado en HTML semántico, CSS moderno y JavaScript básico. Estoy desarrollando un proyecto web cuyo propósito es presentar y captar usuarios para la app de productividad TaskFlow, dirigido a estudiantes y profesionales jóvenes de 18 a 35 años. El sitio debe incluir un Header, Hero Section, Características en tarjetas, Testimonios, Formulario de registro interactivo y Footer, utilizando una estética moderna, minimalista y tech con colores azul (#2563eb) y verde esmeralda (#10b981).
> Su función será ayudarme a diseñar, maquetar y validar la propuesta. Trabaja con HTML, CSS y JavaScript puro, separando las tres tecnologías en archivos independientes. Prioriza la accesibilidad, la claridad del código, el diseño responsive y la facilidad de mantenimiento. No utilices frameworks externos ni generes funcionalidades innecesarias.
> Primero ayúdame a definir la propuesta; después esperaremos mi aprobación para generar el código. Explica sus decisiones mediante resúmenes y criterios técnicos verificables. ¿Qué información adicional necesitas antes de comenzar?

**Información adicional solicitada por la IA:**
- Confirmación sobre la estructura exacta del formulario.
- Preferencias específicas de puntos de interrupción (*breakpoints*) para responsive design (360px, 768px, 1200px).
- Validaciones requeridas en JavaScript.

---

## Actividad 3: Meta-prompting
**Prompt enviado:**
> Quiero crear una propuesta profesional de diseño y maquetación web para el proyecto que te describí. Antes de generar la propuesta, indícame cuál sería la mejor estructura de un prompt para obtener un resultado preciso. Identifica los datos que necesitas sobre el diseño visual, las secciones, la navegación, las interacciones, las imágenes y la adaptación a móviles. Devuélveme una plantilla organizada por campos, señala qué información falta en mi brief y formula las preguntas necesarias para completarlo. No generes todavía HTML, CSS ni JavaScript.

---

## Actividad 4: Experimentación con 4 Técnicas de Prompting

### Reto 1: Zero-shot (Sin ejemplos)
- **Prompt:** "Diseña la propuesta visual de una página web para la landing page de la app TaskFlow. Define las secciones, su orden, una paleta de colores con códigos HEX, la tipografía y las principales interacciones. Presenta la propuesta en una estructura organizada. No utilices ejemplos de otros sitios."
- **Registro de Observaciones:** La IA generó una estructura genérica. Eligió colores estándar y tomó decisiones autónomas sobre el formulario, pero faltó especificidad en el diseño responsive y componentes interactivos.

### Reto 2: One-shot (Un ejemplo de referencia)
- **Prompt:** "Ejemplo de referencia: sección de servicios con título alineado a la izquierda, texto introductorio y tres tarjetas en una fila. Cada tarjeta contiene un icono, un título, una descripción breve y un botón. En móvil, las tarjetas se apilan verticalmente. Diseña la propuesta visual de TaskFlow utilizando el ejemplo anterior como referencia para la organización de la sección de características. Conserva el patrón de jerarquía visual, pero adapta los contenidos, colores y elementos al propósito y la audiencia de mi sitio. Explica qué partes del patrón reutilizaste."
- **Registro de Observaciones:** La IA adaptó el patrón de tarjetas de 3 columnas de manera clara, manteniendo el apilamiento vertical en móviles. Reutilizó la jerarquía visual respetando la identidad del brief.

### Reto 3: Few-shot (Varias referencias)
- **Prompt:** "Referencias: (1) Tarjetas: fondo blanco, bordes suaves, sombra discreta y espaciado uniforme. (2) Botones: color primario consistente (#2563eb), texto legible y estados hover (#1d4ed8) y focus visibles. (3) Secciones: título, descripción breve y contenido organizado en una cuadrícula responsive. Diseña la propuesta visual de TaskFlow. Utiliza las tres referencias como convenciones para los componentes correspondientes. Mantén consistencia en bordes, espaciado, jerarquía tipográfica y estados interactivos."
- **Registro de Observaciones:** La propuesta producida fue altamente consistente. Todos los componentes de la interfaz compartieron el mismo lenguaje visual (sombras, bordes redondeados y transiciones).

### Reto 4: Chain of Thought (Planificación paso a paso)
- **Prompt:** "Antes de generar la propuesta visual de TaskFlow, presenta un plan de trabajo con estas etapas: 1. identificar las necesidades del usuario; 2. definir las secciones y su jerarquía; 3. seleccionar colores y tipografía; 4. establecer las interacciones; 5. definir la adaptación a móvil, tablet y escritorio. Para cada etapa, indica las decisiones que propones y una breve justificación técnica verificable. Después presenta la propuesta completa, sin generar todavía el código."
- **Registro de Observaciones:** La planificación previa permitió justificar técnicamente el uso de CSS Grid vs Flexbox y prevenir problemas de desbordamiento horizontal en pantallas de 360px.
