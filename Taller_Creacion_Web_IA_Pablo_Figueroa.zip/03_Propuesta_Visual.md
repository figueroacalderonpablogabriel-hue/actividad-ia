# 03. Propuesta Visual y Arquitectura de Información

## 1. Arquitectura de Información y Secciones
1. **Header Semántico (`<header>`):**
   - Logo a la izquierda (`.logo`): Icono SVG + "TaskFlow".
   - Menú de navegación (`<nav>`): Enlaces a `#caracteristicas`, `#testimonios`, `#contacto`.
   - Botón hamburguesa móvil (`.menu-toggle`) visible solo en pantallas < 768px.
2. **Hero Section (`<section class="hero">`):**
   - Columna izquierda: Badge "Novedad 2026", H1 principal, P descriptivo, Contenedor de botones CTA (`.btn-primary` y `.btn-secondary`).
   - Columna derecha: Ilustración SVG interactiva / Mockup de la app con tarjetas flotantes.
3. **Características (`<section id="caracteristicas">`):**
   - Encabezado de sección (H2 + P).
   - Cuadrícula responsive (`.grid-features`) con 3 tarjetas (`.card`):
     - Tarjeta 1: Gestión Intuitiva (Icono checklist, título, descripción).
     - Tarjeta 2: Sincronización en la Nube (Icono nube, título, descripción).
     - Tarjeta 3: Modo Enfoque Profundo (Icono reloj, título, descripción).
4. **Testimonios (`<section id="testimonios">`):**
   - Cuadrícula responsive de 2 columnas con citas de usuarios, avatares SVG e indicadores de estrellas.
5. **Formulario de Registro (`<section id="contacto">`):**
   - Tarjeta destacada con sombra y borde con el formulario (`<form id="lead-form">`):
     - Campo Nombre (Input text, requerido).
     - Campo Email (Input email, requerido).
     - Campo Nivel de Interés (Select dropdown).
     - Checkbox Términos y Condiciones.
     - Botón de envío (`.btn-block`).
     - Mensaje de feedback dinámico (`#form-message`).
6. **Footer (`<footer>`):**
   - Enlaces rápidos, copyright y aviso de privacidad.

## 2. Sistema de Diseño (Design System)
- **Paleta de Colores:**
  - `--primary-color: #2563eb;`
  - `--primary-hover: #1d4ed8;`
  - `--accent-color: #10b981;`
  - `--bg-color: #f8fafc;`
  - `--card-bg: #ffffff;`
  - `--text-dark: #0f172a;`
  - `--text-muted: #475569;`
  - `--border-color: #e2e8f0;`
- **Tipografía:** System UI Font Stack. H1: 2.5rem / 700 bold, H2: 2rem / 600 semi-bold, Body: 1rem / 400 regular.
- **Espaciados:** Utilización de variables de padding/margin escaladas (0.5rem, 1rem, 1.5rem, 2rem, 4rem).

## 3. Navegación e Interacciones
- **Menú Móvil:** Desplegable dinámico con JavaScript mediante la clase `.active`.
- **Estados Interactivos:** Efecto elevación (`transform: translateY(-4px)`) y sombra intensa en tarjetas al hacer `:hover`.
- **Formulario:** Validación en tiempo real (evento `submit`) con prevención por defecto (`e.preventDefault()`) y despliegue de alerta visual de éxito/error.

## 4. Adaptación Responsive (Breakpoints)
- **Móvil (360px - 767px):** Disposición en 1 sola columna. Menú colapsable. Tarjetas al 100% de ancho.
- **Tablet (768px - 1199px):** Cuadrícula de 2 columnas en características. Menú horizontal desplegado.
- **Escritorio (1200px+):** Layout de 3 columnas en características, 2 columnas en Hero Section. Ancho máximo de contenedor: `1200px`.
