# 01. Brief del Proyecto: Landing Page para App de Productividad (TaskFlow)

## 1. Propósito
El sitio web servirá como una landing page de conversión y presentación para la aplicación móvil de productividad y gestión de tareas "TaskFlow". Sus objetivos principales son:
- Presentar la propuesta de valor y las funciones principales de la aplicación.
- Generar confianza mediante testimonios de usuarios.
- Captar registros de usuarios interesados para la lista de espera / versión Beta a través de un formulario interactivo.

## 2. Audiencia
- **Perfil:** Estudiantes universitarios, profesionales jóvenes y creativos (18 a 35 años).
- **Necesidades:** Herramientas simples, ágiles e intuitivas para organizar sus tareas diarias, proyectos y hábitos sin distracciones.
- **Nivel técnico:** Medio-alto; usuarios habituados a interfaces modernas, diseño minimalista y respuestas dinámicas.
- **Dispositivo habitual:** Principalmente teléfonos móviles (smartphones) y ordenadores portátiles (laptops).

## 3. Contenido y Secciones
1. **Header / Navegación:** Logo de TaskFlow, enlaces a Características, Testimonios y Contacto.
2. **Hero Section:** Encabezado principal impactante, subtítulo explicativo, botones de llamada a la acción (CTA) y mockup ilustrativo.
3. **Sección de Características:** Cuadrícula de 3 tarjetas destacando: Gestión Inteligente, Sincronización Cloud y Modo Enfoque (con iconos y estados interactivos).
4. **Sección de Testimonios:** Tarjetas de opiniones de usuarios satisfechos.
5. **Sección de Registro / Contacto:** Formulario interactivo con validación de campos (Nombre, Email, Nivel de Interés).
6. **Footer:** Derechos de autor y enlaces a redes sociales.

## 4. Estética e Identidad Visual
- **Estilo:** Limpio, moderno, tech-minimalista con enfoque Mobile-First.
- **Paleta de Colores (HEX):**
  - Primario: `#2563eb` (Azul vibrante)
  - Primario Hover: `#1d4ed8` (Azul oscuro)
  - Secundario / Acento: `#10b981` (Verde esmeralda para éxito/CTA)
  - Fondo Principal: `#f8fafc` (Gris muy claro)
  - Fondo Tarjetas: `#ffffff` (Blanco puro)
  - Texto Principal: `#0f172a` (Azul oscuro profundo)
  - Texto Secundario: `#475569` (Gris medio)
  - Bordes y Líneas: `#e2e8f0` (Gris claro)
- **Tipografía:** System Sans-Serif (`system-ui`, `-apple-system`, `BlinkMacSystemFont`, `Segoe UI`, `Roboto`, `sans-serif`) con jerarquía tipográfica definida (h1: 2.5rem, h2: 2rem, p: 1rem).
- **Espaciado y Componentes:** Tarjetas con sombras suaves (`box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1)`), bordes redondeados (`border-radius: 12px`), e interacciones suaves (`transition: all 0.3s ease`).
