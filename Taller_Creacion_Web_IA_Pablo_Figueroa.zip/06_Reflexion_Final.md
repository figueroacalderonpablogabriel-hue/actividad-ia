# 06. Reflexión Final y Conclusiones del Taller

## Respuestas a las preguntas de cierre (Sección 11 del Taller)

1. **¿Cuál de las cuatro técnicas produjo el resultado más útil para su proyecto y por qué?**
   - La técnica **Chain of Thought (Cadena de Pensamiento)** junto con **Few-shot** produjo el mejor resultado. Permitieron planificar primero la jerarquía visual y las restricciones técnicas (CSS Grid/Flexbox), evitando corregir errores de estructura más adelante.

2. **¿Qué diferencia observaste entre proporcionar un ejemplo y proporcionar varios?**
   - En *One-shot* la IA tendió a copiar el patrón de forma rígida. Con *Few-shot*, la IA abstrajo las convenciones (bordes, sombras, botones, espaciado) y las aplicó consistentemente a lo largo de toda la página.

3. **¿Qué información importante surgió al aplicar Meta-prompting?**
   - El Meta-prompting reveló la necesidad de especificar explícitamente los puntos de interrupción (*breakpoints*) y las reglas de validación en JavaScript antes de solicitar la generación de código.

4. **¿Qué cambios introdujiste gracias a la revisión humana que la IA no había considerado?**
   - Se ajustó el contraste de los mensajes de error en el formulario y se añadió `backdrop-filter: blur(8px)` en el header sticky para mejorar la legibilidad sobre el contenido al hacer scroll.

5. **¿Qué errores encontraste en el código generado y cómo los verificaste?**
   - Inicialmente, las tarjetas de características no mantenían la misma altura en pantallas medianas. Se corrigió especificando `height: 100%` en el selector `.card` dentro del CSS.

6. **¿Qué harías diferente si tuvieras que desarrollar nuevamente el mismo sitio?**
   - Definiría las variables del CSS System Design desde la etapa de *Priming* para garantizar que la IA use exactamente la misma nomenclatura desde la primera iteración.
