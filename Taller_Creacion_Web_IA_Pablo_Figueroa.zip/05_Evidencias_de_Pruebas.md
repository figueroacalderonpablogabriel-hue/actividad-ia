# 05. Registro de Evidencias de Pruebas y Validación Técnica

## 1. Pruebas de Adaptación Responsive (Breakpoints)
- **Vista Móvil (360 px):**
  - El menú de navegación se oculta dinámicamente y se despliega al tocar el botón hamburguesa.
  - La sección Hero se organiza verticalmente.
  - Las tarjetas de características y testimonios ocupan el 100% del ancho con espaciado de 1.5rem, sin generar desbordamiento horizontal.
- **Vista Tablet (768 px):**
  - El botón hamburguesa desaparece y el menú se integra horizontalmente en el Header.
  - Las tarjetas de testimonios se organizan en 2 columnas.
- **Vista Escritorio (1200 px):**
  - Las características se distribuyen uniformemente en 3 columnas usando CSS Grid.
  - El contenedor principal se centra con un `max-width` de 1200px.

## 2. Validación de HTML y Accesibilidad (WCAG)
- **Etiquetas Semánticas:** Uso correcto de `<header>`, `<nav>`, `<main>`, `<section>`, `<article>`, `<form>` y `<footer>`.
- **Accesibilidad Formulario:** Todos los `<input>` cuentan con su correspondiente `<label for="...">` identificable.
- **Botones:** Botón hamburguesa incluye `aria-label="Abrir menú"`.

## 3. Validación de JavaScript e Interacciones
- Intercepción exitosa del evento `submit` con `preventDefault()`.
- Verificación de correo con expresión regular.
- Visualización de mensaje de éxito sin recargar la página.
- Consola del navegador limpia de errores.
